package com.cybage.test;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

import com.cybage.configuration.LoggerClass;
import com.cybage.service.Database;
import com.cybage.service.SendMailAtDuplicate;
import com.cybage.service.VendorHistory;

public class TestVendorMonthWiseData {
LoggerClass loggerInstance = LoggerClass.getLoggerInstance();
	@Test
	public void testVendorHistory() {
	//VendorHistory vendor = new VendorHistory();
	//loggerInstance.logger.info("USER DL="+Database.getAlluser().size());
	//assertNotNull(vendor.getVendorHistory(201125));
		ArrayList<String> invoiceList = new ArrayList<String>();
		invoiceList.add("17701");
	SendMailAtDuplicate.sendMail("akashpuri","17701#ERS-18888888888-8488#4000#NEFT_2017-11-17_10.28.05.89#17701#ERS-18888888888-8488#4000#NEFT_2017-11-17_10.28.05.89#17701#ERS-18888888888-8488#4000#NEFT_2017-11-17_10.28.05.89#17701#ERS-18888888888-8488#4000#NEFT_2017-11-17_10.28.05.89",invoiceList);
	}
}