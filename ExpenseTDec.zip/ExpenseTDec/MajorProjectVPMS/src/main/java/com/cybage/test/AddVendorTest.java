package com.cybage.test;

import static org.junit.Assert.*;

import org.junit.Test;
import org.springframework.ui.ModelMap;

import com.cybage.service.AddToDB;

public class AddVendorTest {

AddToDB addVendorToDB=new AddToDB();
	
	@Test
	public void testAddVendorToDB() {
		
		String filename="NEFT_2017-09-08_11.31.18.362";
		ModelMap model=new ModelMap();

		//boolean result=addVendorToDB.AddVendorToDb(filename, model);
	
		//assertEquals(true, result);
	}
}