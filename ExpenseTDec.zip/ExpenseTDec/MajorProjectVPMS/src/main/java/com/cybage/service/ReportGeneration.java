package com.cybage.service;


import java.sql.Date;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.TemporalType;

import org.springframework.web.servlet.ModelAndView;

import com.cybage.configuration.LoggerClass;
import com.cybage.model.Aggregateinvoiceinfo;
import com.cybage.model.Invoiceinfo;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

// TODO: Auto-generated Javadoc
/**
 * The Class ReportGeneration.
 */
public class ReportGeneration {
	
	/** The Constant logger. */
	static final LoggerClass loggerInstance = LoggerClass.getLoggerInstance();
	static org.apache.log4j.Logger logger = loggerInstance.logger;

	/**
	 * Gets the percent approved data.
	 *
	 * @param vendorCode the vendor code
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @return the percent approved data
	 * @throws JsonProcessingException the json processing exception
	 */
	@SuppressWarnings("unchecked")
	public static ModelAndView getPercentApprovedData(String vCode,Date fromDate,Date toDate) throws JsonProcessingException{
		String[] code=vCode.split("-");
		int vendorCode=Integer.parseInt(code[0].trim());
		logger.info("Vendor code in function:******************************"+vendorCode);
		ArrayList<Aggregateinvoiceinfo> invoiceList;		
		HashMap<Integer,String> vendorName=new HashMap<Integer,String>();
		HashMap<Integer,Double> approvedCount=new HashMap<Integer,Double>();
		HashMap<Integer,Double> totalRecordCount=new HashMap<Integer,Double>();
		HashMap<Integer,Double> percentApproveCount=new HashMap<Integer,Double>();
		
		ArrayList<String> vendorNameList = new ArrayList<String>();
		 ArrayList<Double> percentApproveList = new ArrayList<Double>(); 
		ModelAndView modelObject=new ModelAndView("approvedCharts");
		EntityManager entityManagerObject=Database.getEntityManager();	
		
		 invoiceList = (ArrayList<Aggregateinvoiceinfo>) entityManagerObject.createQuery(
                 "select s from Aggregateinvoiceinfo s where s.invoiceDate BETWEEN :startDate AND :endDate")
         .setParameter("startDate", fromDate, TemporalType.DATE)
         .setParameter("endDate", toDate, TemporalType.DATE)
         .getResultList();
		 
		 entityManagerObject.close();
		 
		 for (Iterator<Aggregateinvoiceinfo> iterator = invoiceList.iterator(); iterator.hasNext(); ) {
		  	Aggregateinvoiceinfo invoiceinfo = iterator.next();
		  	int vendorcode = invoiceinfo.getVendorCode(); 
		  	if(((invoiceinfo.getInvoiceStatus().equals("Approved"))||(invoiceinfo.getInvoiceStatus().equals("Heldback")))&&((!invoiceinfo.getPane().equals("Satisfied Exception Criteria")))){
				  	
		  		if(totalRecordCount.containsKey(vendorcode)){
		  			double totalCount = totalRecordCount.get(vendorcode);
			 		totalCount++;
					totalRecordCount.put(vendorcode,totalCount);
		  		}else{
				 totalRecordCount.put(vendorcode,(double) 1);
		  		}
		  		
		  	}
		 }
		 for (Iterator<Aggregateinvoiceinfo> iterator = invoiceList.iterator(); iterator.hasNext(); ) {
		  		Aggregateinvoiceinfo invoiceinfo = iterator.next();
	  	 	 if((((invoiceinfo.getInvoiceStatus()).equalsIgnoreCase("Processed")))||(((invoiceinfo.getInvoiceStatus()).equalsIgnoreCase("Unprocessed")))||(invoiceinfo.getPane().equals("Satisfied Exception Criteria"))){
	  	 		 	iterator.remove();
	  	 	    }
			}

		  if(vendorCode!=0){
			  	for (Iterator<Aggregateinvoiceinfo> iterator = invoiceList.iterator(); iterator.hasNext(); ) {
			  		Aggregateinvoiceinfo invoiceinfo = iterator.next();
		  	 	 if(!((invoiceinfo.getVendorCode())==vendorCode)){
		  	 		 	iterator.remove();
		  	 	    }
				}
			  //Compute percent approve
			  	double totalRecords=invoiceList.size();
			  	double approveCount=0;
			  	String vendor_Name="";
			  	
			  	for (Iterator<Aggregateinvoiceinfo> iterator = invoiceList.iterator(); iterator.hasNext(); ) {
			  		Aggregateinvoiceinfo invoiceinfo = iterator.next();
		  	 	 if(invoiceinfo.getInvoiceStatus().equals("Approved")){	
		  	 	        approveCount++;
		  	 	     vendor_Name=invoiceinfo.getVendorName();
		  	 	    }
				}
			  	
			  	logger.info("totalRecords"+totalRecords);
			  	logger.info("approvedCount"+approvedCount);
			  	
			  	double percentApproved=0;
			  	percentApproved= ((approveCount/totalRecords)*100); 
	
			  	logger.info("vendor_Name: "+vendor_Name);
		  	 	logger.info("percentApproved: "+percentApproved);
		  	 	ObjectMapper objectMapper = new ObjectMapper();
		  	 	
		  	 	modelObject.addObject("vendorName",objectMapper.writeValueAsString(vendor_Name));
		  	 	modelObject.addObject("percentApproved",objectMapper.writeValueAsString(percentApproved));
		  		modelObject.addObject("number",objectMapper.writeValueAsString("Percentage of Approved Request"));
		  		modelObject.addObject("title",objectMapper.writeValueAsString("Approve Request Report"));
		  		modelObject.addObject("type",objectMapper.writeValueAsString("bar"));

		  		modelObject.addObject("fromDate",fromDate);
		  		modelObject.addObject("toDate",toDate);
		  		
		  	 	return modelObject;
			  	 }
		 else{
			 for(int i=0;i<invoiceList.size();i++){
				 Aggregateinvoiceinfo aggregateinvoiceinfoObject=invoiceList.get(i);
				 int vendorcode=aggregateinvoiceinfoObject.getVendorCode();
				 String name=aggregateinvoiceinfoObject.getVendorName();
				 if((!vendorName.containsKey(vendorcode))&&(aggregateinvoiceinfoObject.getInvoiceStatus().equalsIgnoreCase("Approved"))){
					 vendorName.put(vendorcode, name);
					 loggerInstance.logger.info("vendorName"+name);
				 }
				 if(aggregateinvoiceinfoObject.getInvoiceStatus().equalsIgnoreCase("Approved")){
				if(approvedCount.containsKey(vendorcode)){
					double value = approvedCount.get(vendorcode);
					value++;
					approvedCount.put(vendorcode, value);
					
				}else{
					approvedCount.put(vendorcode,(double) 1);
				}
				 }
				 
				
			 }
			
			 for(int i=0;i<invoiceList.size();i++){
				 Aggregateinvoiceinfo aggregateinvoiceinfoObject=invoiceList.get(i);
				 int vendorcode=aggregateinvoiceinfoObject.getVendorCode();
				 
				 if((aggregateinvoiceinfoObject.getInvoiceStatus().equalsIgnoreCase("Approved"))&& (!percentApproveCount.containsKey(vendorcode))){
				 
				 double totalRecordOfVendor = totalRecordCount.get(vendorcode);
				 double approvedRecordsOfVendor = approvedCount.get(vendorcode);
				 double percentageApprovedRequest = approvedRecordsOfVendor/totalRecordOfVendor * 100;
				 
				 loggerInstance.logger.info("VALUES FOR totalRecordOfVendor "+totalRecordOfVendor+" approvedRecordsOfVendor"+approvedRecordsOfVendor+" percentageApprovedRequest"+percentageApprovedRequest);
				
				 percentApproveCount.put(vendorcode,percentageApprovedRequest);
				 }
				 
			 }
			 
			 
			 loggerInstance.logger.info(approvedCount);
			 loggerInstance.logger.info(totalRecordCount);
			 loggerInstance.logger.info(percentApproveCount);
			 loggerInstance.logger.info(vendorName);
			 
			 Iterator vendorNameIterator = vendorName.entrySet().iterator();
			    while (vendorNameIterator.hasNext()) {
			        Map.Entry pair = (Map.Entry)vendorNameIterator.next();
			        String value = (String) pair.getValue();
			        vendorNameList.add(value);
			       logger.info("Name map"+pair.getKey() + " = " + pair.getValue());
			    }
			    Iterator percentApproveCountIterator = percentApproveCount.entrySet().iterator();
			    while (percentApproveCountIterator.hasNext()) {
			        Map.Entry pair = (Map.Entry)percentApproveCountIterator.next();
			        Double value = (Double) pair.getValue();
					percentApproveList.add(value);
			       logger.info("Percent="+pair.getKey() + " = " + pair.getValue());
			    }
			    ObjectMapper objectMapper = new ObjectMapper();
		  	 	
		  	 	
	  	 	modelObject.addObject("vendorName",objectMapper.writeValueAsString(vendorNameList));
	  	 	modelObject.addObject("percentApproved",objectMapper.writeValueAsString(percentApproveList));
	  		modelObject.addObject("number",objectMapper.writeValueAsString("Percentage of Approved Request"));
	  		modelObject.addObject("title",objectMapper.writeValueAsString("Approve Request Report"));
	  		modelObject.addObject("type",objectMapper.writeValueAsString("bar"));

	  		modelObject.addObject("fromDate",fromDate);
	  		modelObject.addObject("toDate",toDate);
		 
		return modelObject;
		 }
		 }
	
	/**
	 * Gets the percent heldback data.
	 *
	 * @param vendorCode the vendor code
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @return the percent heldback data
	 * @throws JsonProcessingException the json processing exception
	 */
	@SuppressWarnings("unchecked")
	public static ModelAndView getPercentHeldbackData(String vCode,Date fromDate,Date toDate) throws JsonProcessingException{

		String[] code=vCode.split("-");
		int vendorCode=Integer.parseInt(code[0].trim());
		logger.info("Heldback payment report request for vendor code ="+vendorCode);
		
		ArrayList<Aggregateinvoiceinfo> invoiceList;		
		HashMap<Integer,String> vendorName=new HashMap<Integer,String>();
		HashMap<Integer,Double> approvedCount=new HashMap<Integer,Double>();
		HashMap<Integer,Double> totalRecordCount=new HashMap<Integer,Double>();
		HashMap<Integer,Double> percentApproveCount=new HashMap<Integer,Double>();
		
		ArrayList<String> vendorNameList = new ArrayList<String>();
		 ArrayList<Double> percentApproveList = new ArrayList<Double>(); 
		ModelAndView modelObject=new ModelAndView("heldbackCharts");
		EntityManager entityManagerObject=Database.getEntityManager();	
		
		 invoiceList = (ArrayList<Aggregateinvoiceinfo>) entityManagerObject.createQuery(
                 "select s from Aggregateinvoiceinfo s where s.invoiceDate BETWEEN :startDate AND :endDate")
         .setParameter("startDate", fromDate, TemporalType.DATE)
         .setParameter("endDate", toDate, TemporalType.DATE)
         .getResultList();
		 entityManagerObject.close();
		 for (Iterator<Aggregateinvoiceinfo> iterator = invoiceList.iterator(); iterator.hasNext(); ) {
			  	Aggregateinvoiceinfo invoiceinfo = iterator.next();
			  	int vendorcode = invoiceinfo.getVendorCode(); 
			  	if(((invoiceinfo.getInvoiceStatus().equals("Approved"))||(invoiceinfo.getInvoiceStatus().equals("Heldback")))&&((!invoiceinfo.getPane().equals("Satisfied Exception Criteria")))){
					  	
			  		if(totalRecordCount.containsKey(vendorcode)){
			  			double totalCount = totalRecordCount.get(vendorcode);
				 		totalCount++;
						totalRecordCount.put(vendorcode,totalCount);
			  		}else{
					 totalRecordCount.put(vendorcode,(double) 1);
			  		}
			  		
			  	}
			 }
			 for (Iterator<Aggregateinvoiceinfo> iterator = invoiceList.iterator(); iterator.hasNext(); ) {
			  		Aggregateinvoiceinfo invoiceinfo = iterator.next();
		  	 	 if((((invoiceinfo.getInvoiceStatus()).equalsIgnoreCase("Processed")))||(((invoiceinfo.getInvoiceStatus()).equalsIgnoreCase("Unprocessed")))||(invoiceinfo.getPane().equals("Satisfied Exception Criteria"))){
		  	 		 	iterator.remove();
		  	 	    }
				}

		 if(vendorCode!=0){
			 for (Iterator<Aggregateinvoiceinfo> iterator = invoiceList.iterator(); iterator.hasNext(); ) {
			  		Aggregateinvoiceinfo invoiceinfo = iterator.next();
		  	 	 if(!((invoiceinfo.getVendorCode())==vendorCode)){
		  	 		 	iterator.remove();
		  	 	    }
				}
			  //Compute percent approve
			  	//double totalRecords=totalRecordCount.get(vendorCode);
			  	double totalRecords=invoiceList.size();
			  	double approveCount=0;
			  	String vendorName1 = null;
			  	
			  	for (Iterator<Aggregateinvoiceinfo> iterator = invoiceList.iterator(); iterator.hasNext(); ) {
			  		Aggregateinvoiceinfo invoiceinfo = iterator.next();
		  	 	 if(invoiceinfo.getInvoiceStatus().equals("Heldback")){	
		  	 	        approveCount++;
		  	 	     vendorName1=invoiceinfo.getVendorName();
		  	 	    }
				}
			  	
			  	logger.info("totalRecords"+totalRecords);
			  	logger.info("approvedCount"+approvedCount);
			  	
			  	double percentApproved = ((approveCount/totalRecords)*100); 
	
			  	logger.info("vendor_Name: "+vendorName1);
		  	 	logger.info("percentApproved: "+percentApproved);
		  	 	ObjectMapper objectMapper = new ObjectMapper();
		  	 	
		  	 	modelObject.addObject("vendorName",objectMapper.writeValueAsString(vendorName1));
		  	 	modelObject.addObject("percentApproved",objectMapper.writeValueAsString(percentApproved));
		  		modelObject.addObject("number",objectMapper.writeValueAsString("Percentage of Heldback Request"));
		  		modelObject.addObject("title",objectMapper.writeValueAsString("Heldback Request Report"));
		  		modelObject.addObject("type",objectMapper.writeValueAsString("bar"));

		  		modelObject.addObject("fromDate",fromDate);
		  		modelObject.addObject("toDate",toDate);
		  		
		  	 	return modelObject;
			  	 }
		 else{
			 for(int i=0;i<invoiceList.size();i++){
				 Aggregateinvoiceinfo aggregateinvoiceinfoObject=invoiceList.get(i);
				 int vendorcode=aggregateinvoiceinfoObject.getVendorCode();
				 String name=aggregateinvoiceinfoObject.getVendorName();
				 if((!vendorName.containsKey(vendorcode))&&(aggregateinvoiceinfoObject.getInvoiceStatus().equalsIgnoreCase("Heldback"))){
					 vendorName.put(vendorcode, name);
					 logger.info("vendorName"+name);
				 }
				 if(aggregateinvoiceinfoObject.getInvoiceStatus().equalsIgnoreCase("Heldback")){
				if(approvedCount.containsKey(vendorcode)){
					double value = approvedCount.get(vendorcode);
					value++;
					approvedCount.put(vendorcode, value);
					
				}else{
					approvedCount.put(vendorcode,(double) 1);
				}
				 }				
			 }
			
			 for(int i=0;i<invoiceList.size();i++){
				 Aggregateinvoiceinfo aggregateinvoiceinfoObject=invoiceList.get(i);
				 int vendorcode=aggregateinvoiceinfoObject.getVendorCode();
				 
				 if((aggregateinvoiceinfoObject.getInvoiceStatus().equalsIgnoreCase("Heldback"))&& (!percentApproveCount.containsKey(vendorcode))){
				 
				 double totalRecordOfVendor = totalRecordCount.get(vendorcode);
				 double approvedRecordsOfVendor = approvedCount.get(vendorcode);
				 double percentageApprovedRequest = approvedRecordsOfVendor/totalRecordOfVendor * 100;
				 
				 loggerInstance.logger.info("VALUES FOR totalRecordOfVendor "+totalRecordOfVendor+" approvedRecordsOfVendor"+approvedRecordsOfVendor+" percentageApprovedRequest"+percentageApprovedRequest);
				
				 percentApproveCount.put(vendorcode,percentageApprovedRequest);
				 }
				 
			 }
			 
			 
			 loggerInstance.logger.info(approvedCount);
			 loggerInstance.logger.info(totalRecordCount);
			 loggerInstance.logger.info(percentApproveCount);
			 loggerInstance.logger.info(vendorName);
			 
			 Iterator vendorNameIterator = vendorName.entrySet().iterator();
			    while (vendorNameIterator.hasNext()) {
			        Map.Entry pair = (Map.Entry)vendorNameIterator.next();
			        String value = (String) pair.getValue();
			        vendorNameList.add(value);
			       logger.info("Name map"+pair.getKey() + " = " + pair.getValue());
			    }
			    Iterator percentApproveCountIterator = percentApproveCount.entrySet().iterator();
			    while (percentApproveCountIterator.hasNext()) {
			        Map.Entry pair = (Map.Entry)percentApproveCountIterator.next();
			        Double value = (Double) pair.getValue();
					percentApproveList.add(value);
			       logger.info("Percent="+pair.getKey() + " = " + pair.getValue());
			    }
			    ObjectMapper objectMapper = new ObjectMapper();
		  	 	
	  	 	
	  	 	modelObject.addObject("vendorName",objectMapper.writeValueAsString(vendorNameList));
	  	 	modelObject.addObject("percentApproved",objectMapper.writeValueAsString(percentApproveList));
	  	 	modelObject.addObject("number",objectMapper.writeValueAsString("Percentage of Heldback Request"));
	  		modelObject.addObject("title",objectMapper.writeValueAsString("Heldback Request Report"));
	  		modelObject.addObject("type",objectMapper.writeValueAsString("bar"));

	  		modelObject.addObject("fromDate",fromDate);
	  		modelObject.addObject("toDate",toDate);
		 
		return modelObject;
		 }
		
	}
	
	/**
	 * Gets the percent payment data.
	 *
	 * @param vendorCode the vendor code
	 * @param fromDate the from date
	 * @param toDate the to date
	 * @return the percent payment data
	 * @throws JsonProcessingException the json processing exception
	 */
	@SuppressWarnings("unchecked")
	public static ModelAndView getPercentPaymentData(String vCode,
			Date fromDate, Date toDate) throws JsonProcessingException {
		String[] code=vCode.split("-");
		int vendorCode=Integer.parseInt(code[0].trim());
		logger.info("Vendor code in function:******************************"+vendorCode);
		ArrayList<Aggregateinvoiceinfo> invoiceList;		
		HashMap<Integer,String> vendorName=new HashMap<Integer,String>();
		HashMap<Integer,Double> paymentMap=new HashMap<Integer,Double>();
		
		ArrayList<String> vendorNameList = new ArrayList<String>();
		ArrayList<Double> paymentList = new ArrayList<Double>(); 
		
		 ModelAndView modelObject=new ModelAndView("paymentCharts");
		EntityManager entityManagerObject=Database.getEntityManager();	
		
		 invoiceList = (ArrayList<Aggregateinvoiceinfo>) entityManagerObject.createQuery(
                 "select s from Aggregateinvoiceinfo s where s.invoiceDate BETWEEN :startDate AND :endDate")
         .setParameter("startDate", fromDate, TemporalType.DATE)
         .setParameter("endDate", toDate, TemporalType.DATE)
         .getResultList();
		
		 entityManagerObject.close();
		 
		if(vendorCode!=0){
			for (Iterator<Aggregateinvoiceinfo> iterator = invoiceList.iterator(); iterator.hasNext(); ) {
		  		Aggregateinvoiceinfo invoiceinfo = iterator.next();
	  	 	 if(!((invoiceinfo.getVendorCode())==vendorCode)){
	  	 		 	iterator.remove();
	  	 	    }
			}
		  //Compute percent approve
		  	double paymentAmount=0;
		  	String vendor_Name="";
		  	
		  	for (Iterator<Aggregateinvoiceinfo> iterator = invoiceList.iterator(); iterator.hasNext(); ) {
		  		Aggregateinvoiceinfo invoiceinfo = iterator.next();
		  		if(invoiceinfo.getInvoiceStatus().equals("Approved")){
	  	 	     vendor_Name=invoiceinfo.getVendorName();
	  	 	     paymentAmount +=invoiceinfo.getPaymentAmount();
		  		}
			}
		  	logger.info("vendor_Name: "+vendor_Name);
		  	logger.info("paymentAmount: "+paymentAmount);
	  	 	
ObjectMapper objectMapper = new ObjectMapper();	 		
	   	 	
	   	 	modelObject.addObject("vendorName",objectMapper.writeValueAsString(vendor_Name));
	   	 	modelObject.addObject("percentApproved",objectMapper.writeValueAsString(paymentAmount));
	   	 	modelObject.addObject("number",objectMapper.writeValueAsString("Total Payment Request"));
	   	 	modelObject.addObject("title",objectMapper.writeValueAsString("Total Payment Request Report"));
	   	 	modelObject.addObject("type",objectMapper.writeValueAsString("bar"));
	   	 	
	   	 modelObject.addObject("fromDate",fromDate);
	  		modelObject.addObject("toDate",toDate);
		}
		else{
			
			for(int index=0;index<invoiceList.size();index++){
				Aggregateinvoiceinfo aggregateinvoiceinfoObject=invoiceList.get(index);
				if(aggregateinvoiceinfoObject.getInvoiceStatus().equals("Approved")){
				int vendorcode=aggregateinvoiceinfoObject.getVendorCode();
				 String name=aggregateinvoiceinfoObject.getVendorName();
				 
				 if(!vendorName.containsKey(vendorcode)){
					 vendorName.put(vendorcode, name);
				 }
				 
				 if(paymentMap.containsKey(vendorcode)){
					 double paymentAmount = paymentMap.get(vendorcode);
					 paymentAmount = paymentAmount+aggregateinvoiceinfoObject.getPaymentAmount();
					 paymentMap.put(vendorcode, paymentAmount);
				 }
				 else{
					 paymentMap.put(vendorcode, (double)aggregateinvoiceinfoObject.getPaymentAmount());
				 }
				}
			}
			Iterator vendorNameIterator = vendorName.entrySet().iterator();
		    while (vendorNameIterator.hasNext()) {
		        Map.Entry pair = (Map.Entry)vendorNameIterator.next();
		        String value = (String) pair.getValue();
		        vendorNameList.add(value);
		       logger.info(pair.getKey() + " = " + pair.getValue());
		    }
			
		    Iterator paymentAmountIterator = paymentMap.entrySet().iterator();
		    while (paymentAmountIterator.hasNext()) {
		        Map.Entry pair = (Map.Entry)paymentAmountIterator.next();
		        
		        Double value = (Double) pair.getValue();
		        paymentList.add(value);
		       logger.info(pair.getKey() + " = " + pair.getValue());
		    }
		    ObjectMapper objectMapper = new ObjectMapper();
		  	 //result.addObject("list", objectMapper.writeValueAsString(list));  	 	
	  	
		  	 modelObject.addObject("vendorName",objectMapper.writeValueAsString(vendorNameList));
		  	 modelObject.addObject("percentApproved",objectMapper.writeValueAsString(paymentList));
		  	 modelObject.addObject("number",objectMapper.writeValueAsString("Percentage of Total Payment Request"));
		  	 modelObject.addObject("title",objectMapper.writeValueAsString("Total Payment Request Report"));
		  	 modelObject.addObject("type",objectMapper.writeValueAsString("bar"));

		  	modelObject.addObject("fromDate",fromDate);
	  		modelObject.addObject("toDate",toDate);
		}
  	 	return modelObject;	
	}
	
	//Exceptional criteria function.
	
	@SuppressWarnings("unchecked")
	public static ModelAndView getExceptionalReport(String vCode,
			Date fromDate, Date toDate) throws JsonProcessingException {
		String[] code=vCode.split("-");
		int vendorCode=Integer.parseInt(code[0].trim());
		logger.info("Vendor code in function:"+vendorCode);
		ArrayList<Aggregateinvoiceinfo> invoiceList;		
		HashMap<Integer,String> vendorName=new HashMap<Integer,String>();
		HashMap<Integer,Double> paymentApprovedMap=new HashMap<Integer,Double>();
		HashMap<Integer,Double> paymentHeldbackMap=new HashMap<Integer,Double>();
		HashMap<Integer,Double> paymentRejectedMap=new HashMap<Integer,Double>();
		
		
		ArrayList<String> vendorNameList = new ArrayList<String>();
		ArrayList<Double> paymentApprovedList = new ArrayList<Double>(); 
		ArrayList<Double> paymentHeldbackList = new ArrayList<Double>(); 
		ArrayList<Double> paymentRejectedList = new ArrayList<Double>(); 
		
		 ModelAndView modelObject=new ModelAndView("ExceptionalCharts");
		EntityManager entityManagerObject=Database.getEntityManager();	
		
		 invoiceList = (ArrayList<Aggregateinvoiceinfo>) entityManagerObject.createQuery(
                 "select s from Aggregateinvoiceinfo s where s.invoiceDate BETWEEN :startDate AND :endDate")
         .setParameter("startDate", fromDate, TemporalType.DATE)
         .setParameter("endDate", toDate, TemporalType.DATE)
         .getResultList();
		
		 entityManagerObject.close();
		 for (Iterator<Aggregateinvoiceinfo> iterator = invoiceList.iterator(); iterator.hasNext(); ) {
		  		Aggregateinvoiceinfo invoiceinfo = iterator.next();
	  	 	 if(!invoiceinfo.getPane().equals("Satisfied Exception Criteria")){
	  	 		 	iterator.remove();
	  	 	    }
	  	 	 else if(invoiceinfo.getInvoiceStatus().equals("Processed")){
	  	 		 	iterator.remove();
	  	 	    }
			}
		
		if(vendorCode!=0){
			for (Iterator<Aggregateinvoiceinfo> iterator = invoiceList.iterator(); iterator.hasNext(); ) {
		  		Aggregateinvoiceinfo invoiceinfo = iterator.next();
	  	 	 if(!((invoiceinfo.getVendorCode())==vendorCode)){
	  	 		 	iterator.remove();
	  	 	    }
			}
		  //Compute percent approve
		  	double paymentAmountApproved=0;
		  	double paymentAmountHeldback=0;
		  	double paymentAmountRejected=0;
		  	String vendor_Name="";
		  	
		  	for (Iterator<Aggregateinvoiceinfo> iterator = invoiceList.iterator(); iterator.hasNext(); ) {
		  		Aggregateinvoiceinfo invoiceinfo = iterator.next();
		  		if(invoiceinfo.getInvoiceStatus().equals("Approved")){
	  	 	     vendor_Name=invoiceinfo.getVendorName();
	  	 	     paymentAmountApproved +=invoiceinfo.getPaymentAmount();
		  		}
		  		if(invoiceinfo.getInvoiceStatus().equals("Heldback")){
		  	 	     vendor_Name=invoiceinfo.getVendorName();
		  	 	  paymentAmountHeldback +=invoiceinfo.getPaymentAmount();
			  		}
		  		paymentAmountRejected +=invoiceinfo.getPendingPayment();
			}
		  	logger.info("vendor_Name: "+vendor_Name);
	  	 	
ObjectMapper objectMapper = new ObjectMapper();	 		
	   	 	
	   	 	modelObject.addObject("vendorName",objectMapper.writeValueAsString(vendor_Name));
	   	 	modelObject.addObject("paymentApproved",objectMapper.writeValueAsString(paymentAmountApproved));
	   	 	modelObject.addObject("paymentHeldback",objectMapper.writeValueAsString(paymentAmountHeldback));
	   	 	modelObject.addObject("paymentRejected",objectMapper.writeValueAsString(paymentAmountRejected));
	   	
	   	 	modelObject.addObject("number",objectMapper.writeValueAsString("Exceptional criteria Report"));
	   	 	modelObject.addObject("title",objectMapper.writeValueAsString("Exceptional criteria Report"));
	   	 	modelObject.addObject("type",objectMapper.writeValueAsString("bar"));
	   	 	
	   	 modelObject.addObject("fromDate",fromDate);
	  		modelObject.addObject("toDate",toDate);
		}
		else{
			logger.info("invoice "+invoiceList.size());
			for(int index=0;index<invoiceList.size();index++){
				Aggregateinvoiceinfo aggregateinvoiceinfoObject=invoiceList.get(index);
				int vendorcode=aggregateinvoiceinfoObject.getVendorCode();
				if(aggregateinvoiceinfoObject.getInvoiceStatus().equals("Approved")){				
				 String name=aggregateinvoiceinfoObject.getVendorName();				 
				 if(!vendorName.containsKey(vendorcode)){
					 vendorName.put(vendorcode, name);
				 }
				 
				 if(paymentApprovedMap.containsKey(vendorcode)){
					 double paymentAmount = paymentApprovedMap.get(vendorcode);
					
					 paymentAmount = paymentAmount+aggregateinvoiceinfoObject.getPaymentAmount();
					 paymentApprovedMap.put(vendorcode, paymentAmount);
				 }
				 else{
					 paymentApprovedMap.put(vendorcode, (double)aggregateinvoiceinfoObject.getPaymentAmount());
				 }
				}	
				else{
					 if(!paymentApprovedMap.containsKey(vendorcode)){
						 paymentApprovedMap.put(vendorcode, (double)0);
					 }					 
				}
				if(aggregateinvoiceinfoObject.getInvoiceStatus().equals("Heldback")){
					
					 String name=aggregateinvoiceinfoObject.getVendorName();
					 
					 if(!vendorName.containsKey(vendorcode)){
						 vendorName.put(vendorcode, name);
					 }
					 
					 if(paymentHeldbackMap.containsKey(vendorcode)){
						 double paymentAmount = paymentHeldbackMap.get(vendorcode);
						 paymentAmount = paymentAmount+aggregateinvoiceinfoObject.getPaymentAmount();
						 paymentHeldbackMap.put(vendorcode, paymentAmount);
					 }
					 else{
						 paymentHeldbackMap.put(vendorcode, (double)aggregateinvoiceinfoObject.getPaymentAmount());
					 }
					}
				else{
					 if(!paymentHeldbackMap.containsKey(vendorcode)){
						 paymentHeldbackMap.put(vendorcode, (double)0);
					 }	 
				}
				// reject
				if(paymentRejectedMap.containsKey(vendorcode)){
					 double paymentAmount = paymentRejectedMap.get(vendorcode);
					 paymentAmount = paymentAmount+aggregateinvoiceinfoObject.getPendingPayment();
					 paymentRejectedMap.put(vendorcode, paymentAmount);
				 }
				 else{
					 paymentRejectedMap.put(vendorcode, (double)aggregateinvoiceinfoObject.getPendingPayment());
				 }
			}
		
			
			Iterator vendorNameIterator = vendorName.entrySet().iterator();
		    while (vendorNameIterator.hasNext()) {
		        Map.Entry pair = (Map.Entry)vendorNameIterator.next();
		        String value = (String) pair.getValue();
		        vendorNameList.add(value);
		       logger.info(pair.getKey() + " = " + pair.getValue());
		    }
			
		    Iterator paymentAmountIterator = paymentApprovedMap.entrySet().iterator();
		    while (paymentAmountIterator.hasNext()) {
		        Map.Entry pair = (Map.Entry)paymentAmountIterator.next();
		        
		        Double value = (Double) pair.getValue();
		        paymentApprovedList.add(value);
		       logger.info("Approved"+pair.getKey() + " = " + pair.getValue());
		    }
		    
		    Iterator paymentHeldbackAmountIterator = paymentHeldbackMap.entrySet().iterator();
		    while (paymentHeldbackAmountIterator.hasNext()) {
		        Map.Entry pair = (Map.Entry)paymentHeldbackAmountIterator.next();
		        
		        Double value = (Double) pair.getValue();
		        paymentHeldbackList.add(value);
		       logger.info("Heldback"+pair.getKey() + " = " + pair.getValue());
		    }
		    Iterator paymentRejectedAmountIterator = paymentRejectedMap.entrySet().iterator();
		    while (paymentRejectedAmountIterator.hasNext()) {
		        Map.Entry pair = (Map.Entry)paymentRejectedAmountIterator.next();
		        
		        Double value = (Double) pair.getValue();
		        paymentRejectedList.add(value);
		       logger.info("rejected"+pair.getKey() + " = " + pair.getValue());
		    }
		    
		    ObjectMapper objectMapper = new ObjectMapper();
		  	 //result.addObject("list", objectMapper.writeValueAsString(list));  	 	
	  	
		    modelObject.addObject("vendorName",objectMapper.writeValueAsString(vendorNameList));
	   	 	modelObject.addObject("paymentApproved",objectMapper.writeValueAsString(paymentApprovedList));
	   	 	modelObject.addObject("paymentHeldback",objectMapper.writeValueAsString(paymentHeldbackList));
	   	 	modelObject.addObject("paymentRejected",objectMapper.writeValueAsString(paymentRejectedList));
	   	
	   	 	modelObject.addObject("number",objectMapper.writeValueAsString("Exceptional criteria Report"));
	   	 	modelObject.addObject("title",objectMapper.writeValueAsString("Exceptional criteria Report"));
	   	 	modelObject.addObject("type",objectMapper.writeValueAsString("bar"));
	   	 	
		  	modelObject.addObject("fromDate",fromDate);
	  		modelObject.addObject("toDate",toDate);
		}
  	 	return modelObject;	
	}

@SuppressWarnings("unchecked")
public static ModelAndView getMonthlyPayment() {
		
		ArrayList<Aggregateinvoiceinfo> invoiceList;		
		HashMap<Integer,String> vendorName=new HashMap<Integer,String>();
		HashMap<Integer,Double> paymentMap=new HashMap<Integer,Double>();
		
		ArrayList<String> vendorNameList = new ArrayList<String>();
		ArrayList<Double> paymentList = new ArrayList<Double>();
		
		ModelAndView modelObject=new ModelAndView("superAdminReport");
		EntityManager entityManagerObject=Database.getEntityManager();	
		int month=Calendar.getInstance().get(Calendar.MONTH)+1;		
		Date first=java.sql.Date.valueOf(LocalDate.now().with( TemporalAdjusters.firstDayOfMonth()).toString());
		Date last=java.sql.Date.valueOf(LocalDate.now().with( TemporalAdjusters.lastDayOfMonth()).toString());
		logger.info(month+"...."+first+"......"+last);
		
		 invoiceList = (ArrayList<Aggregateinvoiceinfo>) entityManagerObject.createQuery(
                 "select s from Aggregateinvoiceinfo s where s.invoiceDate BETWEEN :startDate AND :endDate")
         .setParameter("startDate", first, TemporalType.DATE)
         .setParameter("endDate", last, TemporalType.DATE)
         .getResultList();
		 
		 entityManagerObject.close();
		
		 //Removing entries which are not approved
  		 for (Iterator<Aggregateinvoiceinfo> iterator = invoiceList.iterator(); iterator.hasNext(); ) {
  			Aggregateinvoiceinfo invoiceinfo = iterator.next();
  			 if((invoiceinfo.getInvoiceStatus().equals("Unprocessed"))||(invoiceinfo.getInvoiceStatus().equals("Processed"))||(invoiceinfo.getInvoiceStatus().equals("Heldback"))){
  				 iterator.remove();
  			 }
  		 }
  		 
		 for(int index=0;index<invoiceList.size();index++){
				Aggregateinvoiceinfo aggregateinvoiceinfoObject=invoiceList.get(index);
				 int vendorcode=aggregateinvoiceinfoObject.getVendorCode();
				 String name=aggregateinvoiceinfoObject.getVendorName();
				
				 if(!vendorName.containsKey(vendorcode)){
					 vendorName.put(vendorcode, name);
				 }
				 
				 if(paymentMap.containsKey(vendorcode)){
					 double paymentAmount = paymentMap.get(vendorcode);
					 paymentAmount = paymentAmount+aggregateinvoiceinfoObject.getPaymentAmount();
					 paymentMap.put(vendorcode, paymentAmount);
				 }
				 else{
					 paymentMap.put(vendorcode, (double)aggregateinvoiceinfoObject.getPaymentAmount());
				 }
			}
			Iterator vendorNameIterator = vendorName.entrySet().iterator();
		    while (vendorNameIterator.hasNext()) {
		        Map.Entry pair = (Map.Entry)vendorNameIterator.next();
		        String value = (String) pair.getValue();
		        vendorNameList.add(value);
		       /* vendorCodeList.add(pair.getKey()+"-"+value);*/
		       logger.info(pair.getKey() + " = " + pair.getValue());
		    }
			
		    Iterator paymentAmountIterator = paymentMap.entrySet().iterator();
		    while (paymentAmountIterator.hasNext()) {
		        Map.Entry pair = (Map.Entry)paymentAmountIterator.next();
		        
		        Double value = (Double) pair.getValue();
		        paymentList.add(value);
		       logger.info(pair.getKey() + " = " + pair.getValue());
		    }
		    
		    ArrayList<String> vendorList=ReportGeneration.getVendorDetails();
			
		    ObjectMapper objectMapper = new ObjectMapper();
		    
		  	 try {
				modelObject.addObject("vendorName",objectMapper.writeValueAsString(vendorNameList));
				modelObject.addObject("vendorList",vendorList);				
				modelObject.addObject("percentApproved",objectMapper.writeValueAsString(paymentList));
				modelObject.addObject("number",objectMapper.writeValueAsString("Percentage of Total Payment Request"));
				modelObject.addObject("title",objectMapper.writeValueAsString("Total Payment Request Report"));
				modelObject.addObject("type",objectMapper.writeValueAsString("bar"));
				
				Calendar mCalendar = Calendar.getInstance();    
				String monthName = mCalendar.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.getDefault());
				
				modelObject.addObject("currentMonth",monthName);
				
		  	} catch (JsonProcessingException e) {
				logger.error(e);
			}
		  	 
		return modelObject;
	}
	
@SuppressWarnings("unchecked")
public static ArrayList< String> getVendorDetails() {
		ArrayList<Aggregateinvoiceinfo> vendorDetails;		
	ArrayList<Integer> vendorIdList=new ArrayList<Integer>();
	ArrayList<String> vendorCodeList = new ArrayList<String>(); 
	EntityManager entityManagerObject=Database.getEntityManager();	
	
	
	vendorCodeList.add(0+"-"+"All Vendors");
	
	vendorDetails = (ArrayList<Aggregateinvoiceinfo>) entityManagerObject.createQuery
			("select s from Aggregateinvoiceinfo s").getResultList();
	
	for(int index=0;index<vendorDetails.size();index++){
		if(!vendorIdList.contains(vendorDetails.get(index).getVendorCode())){
			vendorIdList.add(vendorDetails.get(index).getVendorCode());
			vendorCodeList.add(vendorDetails.get(index).getVendorCode()+"-"+vendorDetails.get(index).getVendorName());
		}
	}
	entityManagerObject.close();		
	
	   return vendorCodeList;
}
}
