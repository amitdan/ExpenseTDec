package com.cybage.service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import com.cybage.configuration.LoggerClass;
import com.cybage.dao.UserDAOImpl;
import com.cybage.model.Aggregateinvoiceinfo;

public class VendorHistory {
	static final LoggerClass loggerInstance = LoggerClass.getLoggerInstance();
	
	public static Map<String,String> getVendorHistory(int vendorCode) {
		Map<String, String> monthAmountMap = new TreeMap<String, String>();
		try {
			Calendar cal = Calendar.getInstance();
			Date today = cal.getTime();
			int currentYear = cal.get(Calendar.YEAR);
			int currentMonth = today.getMonth()+1;
			loggerInstance.logger.info("Current month = "+currentMonth);
			cal.add(Calendar.YEAR, -1); // to get previous year add -1
			Date dateYearBack = cal.getTime();
			java.sql.Date dateToday = getSqlDate(getDateStringFormatted(today.toString()));
			java.sql.Date datePreviousYear = getSqlDate(getDateStringFormatted(dateYearBack.toString()));
			loggerInstance.logger.info(dateToday + " " + datePreviousYear);
			loggerInstance.logger.info("Current month = "+currentMonth);
			loggerInstance.logger.info("Current Year = "+currentYear);
			UserDAOImpl object = new UserDAOImpl();
			List<Aggregateinvoiceinfo> list = object.getVendorAmountMonthwise(vendorCode, dateToday, datePreviousYear);
			loggerInstance.logger.info(list.size());
			
			if (list.isEmpty()) {
					monthAmountMap.put("NEW VENDOR/00", "00");
			} else {
				for (int i = 0; i < list.size(); i++) {
					Aggregateinvoiceinfo o = list.get(i);
					int amount = o.getPaymentAmount();
					int monthNumber = o.getInvoiceDate().getMonth() + 1;
					int year = o.getInvoiceDate().getYear()+1900;
						if (monthAmountMap.containsKey(year+"/"+monthNumber)) {
							loggerInstance.logger.info(monthAmountMap.toString());
							int amountInMap = Integer.parseInt(monthAmountMap.get(year+"/"+monthNumber));
							amountInMap=amountInMap+amount;
							monthAmountMap.put(year+"/"+monthNumber, String.valueOf(amountInMap));
							}
						else{
							loggerInstance.logger.info("NEW AMOUNT ADDED"+amount);
							monthAmountMap.put((year)+"/"+(monthNumber), String.valueOf(amount));
						}
					}
				for (int index = currentMonth-1; index >0; index--) {
					if (!monthAmountMap.containsKey(currentYear+"/"+index)) {
						monthAmountMap.put((currentYear)+"/"+(index), "00");
					}
				}
				for (int index = currentMonth; index <= 12; index++) {
					if (!monthAmountMap.containsKey(currentYear-1+"/"+index)) {
						monthAmountMap.put((currentYear-1)+"/"+(index),"00");	
					}
				}
			}
		}

		catch (Exception e) {
			loggerInstance.logger.error(e);
		}

		loggerInstance.logger.info(monthAmountMap.toString());
		return monthAmountMap;
	}

	

	private static java.sql.Date getSqlDate(String startDate) {
		SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
		java.util.Date date;
		java.sql.Date sqlDate = null;
		try {
			date = sdf1.parse(startDate);
			sqlDate = new java.sql.Date(date.getTime());

		} catch (ParseException e) {
			loggerInstance.logger.error("Exception in invoice date parsing" + e);
		}
		return sqlDate;
	}

	public static String getDateStringFormatted(String inputDate) throws ParseException {
		DateFormat formatter = new SimpleDateFormat("EEE MMM dd HH:mm:ss Z yyyy", Locale.US);
		Date date = formatter.parse(inputDate);
		loggerInstance.logger.info(date);

		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		String formatedDate = cal.get(Calendar.DATE) + "/" + (cal.get(Calendar.MONTH) + 1) + "/"
				+ cal.get(Calendar.YEAR);
		loggerInstance.logger.info("formatedDate : " + formatedDate);
		return formatedDate;
	}

	public static boolean updateAggregateInvoiceRequest(String requestId, String requestStatus, String requestResultPane) {
		boolean result = false;
		try {

			EntityManager entityManagerObject = Database.getEntityManager();

			EntityTransaction updateTransaction = entityManagerObject.getTransaction();
			updateTransaction.begin();

			Query query = entityManagerObject.createQuery(
					"UPDATE Aggregateinvoiceinfo  SET invoiceStatus = ?1,pane = ?2 " + "WHERE id= :parameter");
			query.setParameter(1, requestStatus);
			query.setParameter(2, requestResultPane);
			query.setParameter("parameter", Integer.parseInt(requestId));

			query.executeUpdate();

			updateTransaction.commit();
			result=true;
			entityManagerObject.close();

		} catch (Exception e) {
			loggerInstance.logger.error(e);
		}

		return result;
	}
	public static String getMonthName(String splittingMonth) {
		String monthString;
		int month = Integer.parseInt(splittingMonth);
        switch (month) {
        	case 0 : monthString="0"; break;
            case 1:  monthString = "Jan";       break;
            case 2:  monthString = "Feb";      break;
            case 3:  monthString = "Mar";         break;
            case 4:  monthString = "Apr";         break;
            case 5:  monthString = "May";           break;
            case 6:  monthString = "June";          break;
            case 7:  monthString = "July";          break;
            case 8:  monthString = "Aug";        break;
            case 9:  monthString = "Sep";     break;
            case 10: monthString = "Oct";       break;
            case 11: monthString = "Nov";      break;
            case 12: monthString = "Dec";      break;
            default: monthString = "Invalid month"; break;
        }
		return monthString;
	}
}