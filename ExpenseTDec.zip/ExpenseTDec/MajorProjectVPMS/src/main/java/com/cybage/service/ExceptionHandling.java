package com.cybage.service;

import org.springframework.web.servlet.ModelAndView;

import com.cybage.configuration.LoggerClass;

public class ExceptionHandling {
private static final LoggerClass loggerInstance = LoggerClass.getLoggerInstance();
	public static ModelAndView invalidDatabaseConfiguration(){
		ModelAndView modelObject=new ModelAndView("home.jsp");
		loggerInstance.logger.info("Invalid database configuration");
		return modelObject;
	}
}
