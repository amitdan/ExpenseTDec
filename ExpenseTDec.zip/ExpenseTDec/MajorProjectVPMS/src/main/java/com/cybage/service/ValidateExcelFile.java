package com.cybage.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.cybage.configuration.LoggerClass;


public class ValidateExcelFile {
	public boolean validateExcelFile(String filename) {
		FileInputStream inputStream=null;
		boolean msg=true;
		int flag=1;
		 ArrayList<String> header = new ArrayList<String>();
		 header.add("Sr No.");
		 header.add("Vendor Code");
		 header.add("Vendor Name");
		 header.add("Beneficiary Name");
		 header.add("Invoice Num");
		 header.add("Invoice Date");
		 header.add("Vendor Invoice Num");
		 header.add("Vendor Invoice Date");
		 header.add("Invoice Type");
		 header.add("Invoice Amount");
		 header.add("Prepayment Amount");
		 header.add("Payment Amount");
		 header.add("Description");
		 header.add("PO");
		try {
			inputStream = new FileInputStream(new File(filename));
			Workbook workbook = new XSSFWorkbook(inputStream);
	        Sheet firstSheet = workbook.getSheetAt(0);	
	        XSSFRow row = (XSSFRow) firstSheet.getRow(0);
	        for(int k=1;k<15;k++){
	        	 Cell headerValue=row.getCell(k);
	        	
	        	 if(header.contains(headerValue.toString())){	        		 
	        		 flag=1;
	        	 }
	        	 else{
	        		 flag=0;    
	        		 break;
	             }
	        }
	        if(flag==1)
	        {
	        	return true;
	        }
	        else{
	        	return false;
	        }
	
		} catch (Exception e) {
			msg=false;			
		}
		finally{
			if(inputStream!=null){
			try {
				inputStream.close();
			} catch (IOException e) {
				LoggerClass.getLoggerInstance().logger.error(e);
			}
			}
		}
		return msg;
	}
}