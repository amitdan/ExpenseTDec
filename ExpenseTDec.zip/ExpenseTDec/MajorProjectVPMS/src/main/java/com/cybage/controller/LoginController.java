package com.cybage.controller;


import javax.servlet.http.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.cybage.configuration.LoggerClass;
import com.cybage.dao.LoginDAO;
import com.cybage.model.*;
import com.cybage.service.DirectoryInitialization;
import com.cybage.service.Messages;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;


/**
 * Handles requests for the application login page.
 */
@Controller
public class LoginController extends MultiActionController{
	private static final  LoggerClass loggerInstance = LoggerClass.getLoggerInstance();
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home() {
		DirectoryInitialization.initializeUserDirectories("Temp");
		DirectoryInitialization.initializeUserDirectories("MailFiles");
		DirectoryInitialization.initializeUserDirectories("Files");
		DirectoryInitialization.initializeUserDirectories("InvalidFiles");
		DirectoryInitialization.initializeUserDirectories("TEMPFiles");
		loggerInstance.logger.info("Welcome");		
		return "login";
	}

	@RequestMapping(value = "/loginMain", method = RequestMethod.GET)
	public ModelAndView LoginMain(HttpServletRequest request) {
		loggerInstance.logger.info("Redirected to Login Page");
		HttpSession session=request.getSession();
		session.invalidate();
				
		ModelAndView modelObject = new ModelAndView("login");
		return modelObject;
		
	}
	
	@RequestMapping(value = "/Entry", method = RequestMethod.GET)
	public ModelAndView Login() {
		loggerInstance.logger.info("Redirected to Login Page");
		return new ModelAndView("login", "command", new Login());
	}
	
	@Autowired
    private LoginDAO loginDao;
	@RequestMapping(value = "/display", method = RequestMethod.POST)
	public ModelAndView display(@ModelAttribute("login") Login login, ModelMap model,HttpServletRequest request) throws JsonProcessingException{
		loggerInstance.logger.info("Redirected to Login Check Page");		
		boolean message=loginDao.validate(login.getUsername(),login.getPassword(),request);
		if(message)
		{					
			   String role=loginDao.checkRole(login.getUsername());
	
		  	   if(role.equals("admin")){
		  		 loggerInstance.logger.info("Welcome to admin Home Page");			
		  		   ModelAndView modelObject = new ModelAndView("adminHome");
		  		   modelObject.addObject("value", "admin");
		  		 modelObject.addObject("message", null);
		  		 ObjectMapper objectMapper = new ObjectMapper();
		  		 modelObject.addObject("role",objectMapper.writeValueAsString("admin"));
		  		   return modelObject;
		  	   }		    	
		  	   else if(role.equals("superadmin")){
		  		 loggerInstance.logger.info("Welcome to Super admin Home Page");			
		  		   ModelAndView modelObject = new ModelAndView("superAdminHome");
		  		 modelObject.addObject("message", null);
		  		   ObjectMapper objectMapper = new ObjectMapper();
		  		 modelObject.addObject("role",objectMapper.writeValueAsString("superadmin"));
		  		   return modelObject;
		  	   }		    	
		  	   else if(role.equals("user"))	{
		  		 loggerInstance.logger.info("Welcome to User Home Page");			
		  		   ModelAndView modelObject = new ModelAndView("userHome");					
		  		   modelObject.addObject("value", "user");
		  		   modelObject.addObject("message", null);		  		  
		  		   ObjectMapper objectMapper = new ObjectMapper();
		  		   modelObject.addObject("role",objectMapper.writeValueAsString("user"));
		  		   return modelObject;
		  	   }		    	
		  	   else{
		  		 loggerInstance.logger.info("Invalid username or password");			
					ModelAndView modelObject = new ModelAndView("login");
					modelObject.addObject("message", Messages.UNDEFINED_ROLES);
					return modelObject;
		  	   }		    	
		}
		else{
			loggerInstance.logger.info("Invalid username or password");			
			ModelAndView modelObject = new ModelAndView("login");
			modelObject.addObject("message", Messages.INVALID_CREDENTIALS);
			return modelObject;
		}
	}
	
	@RequestMapping(value = "/display", method = RequestMethod.GET)
	public String invalidRequest(HttpServletRequest request) {
		loggerInstance.logger.info("Invalid Request");
		return "login";
	}
}