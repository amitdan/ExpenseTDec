package com.cybage.service;

import java.io.File;
import java.io.IOException;

import com.cybage.configuration.LoggerClass;

public class DirectoryInitialization {
	static final LoggerClass loggerInstance = LoggerClass.getLoggerInstance(); 
public static void initializeUserDirectories(String directoryName){
	 String path = System.getProperty("user.dir");
	    File f = new File(path + "\\"+directoryName);    
	    
	    if (!f.exists()){
	    	loggerInstance.logger.info("Directory does not exist");
		     f.mkdirs();
		     loggerInstance.logger.info("Created directory"+directoryName);
		 }
}
}
