package com.cybage.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import javax.persistence.EntityManager;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ui.ModelMap;

import com.cybage.configuration.LoggerClass;
import com.cybage.model.*;

// TODO: Auto-generated Javadoc
/**
 * The Class AddVendorToDB.
 */
public class AddToDB {
	
	/** The Constant logger. */
	private static final LoggerClass loggerInstance =  LoggerClass.getLoggerInstance();
	
	/** The upload directory. */
	private static final String UPLOAD_DIRECTORY = System.getProperty("user.dir")+"\\Files\\";
	
	/**
	 * Adds the vendor to db.
	 *
	 * @param filename the filename
	 * @param model the model
	 * @return the string
	 */
	
	@SuppressWarnings("unchecked")
	public String addExcelToDb(String filename, ModelMap model,String createdBy) {
		String excelFilePath = UPLOAD_DIRECTORY+filename+".xlsx";
		 FileInputStream inputStream=null;
		 EntityManager entityManagerObject=Database.getEntityManager();	
		 String message=null; 	
		 try {
			//read excel sheet
				inputStream = new FileInputStream(new File(excelFilePath));
				Workbook workbook = new XSSFWorkbook(inputStream);
		        Sheet firstSheet = workbook.getSheetAt(0);
		        ArrayList<Integer> vendorList = new ArrayList<Integer>();	
		        ArrayList<String> invoiceList = new ArrayList<String>();	
		        ArrayList<Integer> vendorIdList = new ArrayList<Integer>();
		        ArrayList<String> invoiceIdList = new ArrayList<String>();
		        ArrayList<String> duplicateInvoiceList = new ArrayList<String>();
		        
		        vendorList = (ArrayList<Integer>) entityManagerObject.createQuery("select s.vendorCode from Vendorinfo s").getResultList();	 
		        invoiceList = (ArrayList<String>) entityManagerObject.createQuery("select s.invoiceNum from Invoiceinfo s").getResultList();	 
		        Invoiceinfo invoiceinfo=new Invoiceinfo();   
		        Vendorinfo vendorinfo=new Vendorinfo();
		        Invalidinvoiceinfo invalidinvoiceinfo=new Invalidinvoiceinfo();
		        Aggregateinvoiceinfo aggregateinvoiceinfo=new Aggregateinvoiceinfo();
		       //get invoice from sheet
		        HashMap<Integer,ArrayList<String>> vendorMap=new  HashMap<Integer,ArrayList<String>>(); 		       	
		        HashMap<Integer,Integer> vendorPaymentMap=new  HashMap<Integer,Integer>(); 		        
			       
		        int vendorCode,payment,payment1;
		        String invoiceNum , msg="\n";	;
		       
		        //read the paymentsheet and add to vendor table
		        for(int i=1; i<=firstSheet.getLastRowNum(); i++)
		        {	//get row data
		             XSSFRow row = (XSSFRow) firstSheet.getRow(i);		            
		             ////////////////////////////////////////////////
		             //check vendor duplication
		             Cell vCode=row.getCell(2);
		             String invoiceType=row.getCell(9).toString();
		             //check if row is blank
		             if((!vCode.toString().equals(""))&&(invoiceType.equalsIgnoreCase("STANDARD"))){		            	 
		            	 vendorCode=Integer.parseInt(vCode.toString().replace(".0","")); 		            	
		            	 //check if duplicate vendor from database
		            	 if(vendorList.contains(vendorCode)){
		            		 loggerInstance.logger.info("Duplicate Vendor");
		            	 }
		            	 //if not duplicate in database
		            	 else{
		            		 //check if duplicate vendor in sheet
		            		 if(!vendorIdList.contains(vendorCode)){
		            			 vendorIdList.add(Integer.parseInt(row.getCell(2).getRawValue()));
			            		 //adding data to entity
			            		 vendorinfo.setVendorCode(Integer.parseInt(row.getCell(2).getRawValue()));
		 	            		 vendorinfo.setVendorName(row.getCell(3).toString());
		 	            		 vendorinfo.setPurchaseOrder(row.getCell(14).toString().replace(".",""));
		 	            		 vendorinfo.setMinimumPayment(0);
		 	            		 vendorinfo.setMaximumPayment(0);
		 	            		 //insert data to invoiceinfo
		 	            		loggerInstance.logger.info("Insert to table"+vendorCode);
		 	            		 AddToDB.insertToVendorDb(vendorinfo,model);
				             }
		            		 //if duplicate in sheet
				             else if(vendorIdList.contains(vendorCode)){
				            	 loggerInstance.logger.info("Duplicate vendor in file");				             	
				             }		            		
		            	 }		            	
		             }
		             int flag=0;
		             ////////////////////////////////////////////////
		             //check invoice duplication
		             Cell iCode=row.getCell(5);
		             //check if row is blank
		             if(!iCode.toString().equals("")){		            	 
		            	 invoiceNum=iCode.toString();
		            	 if(invoiceList.contains(invoiceNum)){
		            		 loggerInstance.logger.info("Duplicate Invoice Number");
		            		 flag=1;
		            	 }
		            	 //if not duplicate in database
		            	 else{
		            		 //check if duplicate vendor in sheet
		            		 if(!invoiceIdList.contains(invoiceNum)){
		            			 invoiceIdList.add(row.getCell(5).toString());
			            		 //adding data to entity
		            			 invoiceinfo.setInvoiceNum(row.getCell(5).toString());
				 	             invoiceinfo.setInvoiceDate(row.getCell(6).getDateCellValue());
				 	             invoiceinfo.setInvoiceType(row.getCell(9).toString());
				 	             invoiceinfo.setInvoiceAmount(Integer.parseInt(row.getCell(10).toString().replace(".0", "")));
				 	             invoiceinfo.setPrePaymentAmount(Integer.parseInt(row.getCell(11).toString().replace(".0", "")));
				 	             invoiceinfo.setPaymentAmount(Integer.parseInt(row.getCell(12).toString().replace(".0", "")));
				 	             invoiceinfo.setDescription(row.getCell(13).toString());
				 	             invoiceinfo.setBeneficiaryName(row.getCell(4).toString());
				 	             invoiceinfo.setInvoiceStatus("Unprocessed");
				 	             invoiceinfo.setVendorCode(Integer.parseInt(row.getCell(2).toString().replace(".0", "")));
				 	             invoiceinfo.setFileName(filename);
				 	             invoiceinfo.setInvoiceRemark("");
				 	             invoiceinfo.setVendorInvoiceNumber(row.getCell(7).toString());
				 	             invoiceinfo.setVendorInvoiceDate(row.getCell(8).getDateCellValue());
				 	           	
		 	            		 //insert data to invoiceinfo
				 	            loggerInstance.logger.info("Inserting in table for invoice number ");
				 	           loggerInstance.logger.info(invoiceNum);
		 	            		 AddToDB.insertToInvoiceDb(invoiceinfo,model);
		 	            		message=Messages.ADDTODB;
				             }
		            		 //if duplicate in sheet
				             else if(invoiceIdList.contains(invoiceNum)){
				            	 loggerInstance.logger.info("Duplicate invoice Number in file");	
				             	flag=1;
				             }		            		
		            	 }		            	
		             }
		             if(flag==1){
		            	 	duplicateInvoiceList.add(row.getCell(5).toString());
		            	 	invalidinvoiceinfo.setInvoiceNum(row.getCell(5).toString());
	     	            	invalidinvoiceinfo.setInvoiceDate(row.getCell(6).getDateCellValue());
	     	            	invalidinvoiceinfo.setInvoiceType(row.getCell(9).toString());
	     	            	invalidinvoiceinfo.setInvoiceAmount(Integer.parseInt(row.getCell(10).toString().replace(".0", "")));
	     	            	invalidinvoiceinfo.setPrePaymentAmount(Integer.parseInt(row.getCell(11).toString().replace(".0", "")));
	     	            	invalidinvoiceinfo.setPaymentAmount(Integer.parseInt(row.getCell(12).toString().replace(".0", "")));
	     	            	invalidinvoiceinfo.setDescription(row.getCell(13).toString());
	     	            	invalidinvoiceinfo.setBeneficiaryName(row.getCell(4).toString());
	     	            	invalidinvoiceinfo.setInvoiceStatus("Unprocessed");
	     	            	invalidinvoiceinfo.setFilename(filename);
	     	            	invalidinvoiceinfo.setVendorId(Integer.parseInt(row.getCell(2).toString().replace(".0", "")));
	     	            	invalidinvoiceinfo.setVendorInvoiceNumber(row.getCell(7).toString());
	     	            	invalidinvoiceinfo.setVendorInvoiceDate(row.getCell(8).getDateCellValue());
	     	            	invalidinvoiceinfo.setMailStatus("N/A");
	     	            	//insert duplicate to invalidinvoiceinfo
	     	            	loggerInstance.logger.info("Duplicate invoice added to invalidInvoiceInfo table");        		
			        		msg+=invalidinvoiceinfo.getVendorId()+"#";
			 		        msg+=invalidinvoiceinfo.getInvoiceNum()+"#";
			 		        msg+=invalidinvoiceinfo.getPaymentAmount()+"#";
			 		        msg+=invalidinvoiceinfo.getFilename()+"#";		 		       
			 		        AddToDB.insertToDbInvalid(invalidinvoiceinfo,model);
			 		        message = Messages.DUPLICATE_REQUEST;
		             }
		        }
		        if(!duplicateInvoiceList.isEmpty()){
		        	SendMailAtDuplicate.sendMail(createdBy, msg,duplicateInvoiceList);
		        }
		        //read the paymentsheet and add to aggregate sum table
		        for(int i=1; i<=firstSheet.getLastRowNum(); i++)
		        {	//get row data
		             XSSFRow row = (XSSFRow) firstSheet.getRow(i);
		             Cell vCode=row.getCell(2);
		             String invoiceType=row.getCell(9).toString();
		             invoiceNum=row.getCell(5).toString();
		             //check if row is blank
		             if((!vCode.toString().equals(""))&&(invoiceType.equalsIgnoreCase("STANDARD"))&&(!duplicateInvoiceList.contains(invoiceNum))&&(!invoiceList.contains(invoiceNum))){
		            	 vendorCode=Integer.parseInt(vCode.toString().replace(".0","")); 
		            	 ArrayList<String> aggregateList = new ArrayList<String>();
		            		 if(!vendorMap.containsKey(vendorCode)){
		            		
		            			 payment=Integer.parseInt(row.getCell(12).toString().replace(".0", ""));
		            			 aggregateList.add(String.valueOf(vendorCode));
		            			 aggregateList.add(String.valueOf(payment));
		            			 aggregateList.add(row.getCell(3).toString());
		            			 aggregateList.add(row.getCell(6).toString());
		            			 vendorMap.put(vendorCode, aggregateList);
			            		 vendorPaymentMap.put(vendorCode, payment);	
			            		 loggerInstance.logger.info("Added vendor details in map "+vendorCode);
			            	
				             }
		            		 //if duplicate in sheet
				             else if(vendorMap.containsKey(vendorCode)){				             	
				             	payment1=Integer.parseInt(row.getCell(12).toString().replace(".0", ""));
				             	payment=vendorPaymentMap.get(vendorCode).intValue();
				             	vendorPaymentMap.put(vendorCode, payment+payment1); 
				             	 aggregateList.add(String.valueOf(vendorCode));
				             	aggregateList.add(String.valueOf(payment+payment1));
		            			 aggregateList.add(row.getCell(3).toString());
		            			 aggregateList.add(row.getCell(6).toString());
				             	vendorMap.put(vendorCode,aggregateList);	 
				             	loggerInstance.logger.info(""+vendorCode);
				             }        	 		            	
		             }
		        }				
		       SimpleDateFormat inputFormat = new SimpleDateFormat("dd-MMM-yyyy");		
		       loggerInstance.logger.info(vendorMap.values());		    
		      for(ArrayList<String> nextArray : vendorMap.values()) { 
		        	aggregateinvoiceinfo.setVendorCode(Integer.parseInt(nextArray.get(0)));		       
		        	Date date = inputFormat.parse(nextArray.get(3));
		        	SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MMM-yyyy");		        
		        	loggerInstance.logger.info(outputFormat.format(date));
		        	aggregateinvoiceinfo.setPaymentAmount(Integer.parseInt(nextArray.get(1)));
		        	aggregateinvoiceinfo.setVendorName(nextArray.get(2));
		        	aggregateinvoiceinfo.setInvoiceDate(outputFormat.parse(outputFormat.format(date)));
		        	aggregateinvoiceinfo.setInvoiceStatus("Unprocessed");
		  			aggregateinvoiceinfo.setPane("N/A");
		  			aggregateinvoiceinfo.setPendingPayment(0);		  		
		  			aggregateinvoiceinfo.setRemark("N/A");
		  			aggregateinvoiceinfo.setMailStatus("N/A");
		  			AddToDB.insertToSummingDb(aggregateinvoiceinfo,model);
		        }
	       
		 }
		 catch (Exception e) {
			 loggerInstance.logger.error(e);
				message="problem in adding to db";
		}
		finally{			 
			try {
				inputStream.close();
			} catch (IOException e) {				
				loggerInstance.logger.error(e);
			}
		}
		entityManagerObject.close();
		loggerInstance.logger.info("Request processing result = "+message);
		return message;		 
	}
	
	private static void insertToInvoiceDb(Invoiceinfo invoiceinfo, ModelMap model) {
		model.addAttribute("invoiceNum",invoiceinfo.getInvoiceNum());
		model.addAttribute("invoiceDate",invoiceinfo.getInvoiceDate());
		model.addAttribute("invoiceType",invoiceinfo.getInvoiceType());
		model.addAttribute("invoiceAmount",invoiceinfo.getInvoiceAmount());
		model.addAttribute("prePaymentAmount",invoiceinfo.getPrePaymentAmount());
		model.addAttribute("paymentAmount",invoiceinfo.getPaymentAmount());
		model.addAttribute("description",invoiceinfo.getDescription());
		model.addAttribute("beneficiaryName",invoiceinfo.getBeneficiaryName());
		model.addAttribute("invoiceStatus",invoiceinfo.getInvoiceStatus()); 
		model.addAttribute("vendorCode",invoiceinfo.getVendorCode());
		model.addAttribute("filename",invoiceinfo.getFileName());
		model.addAttribute("invoiceRemark",invoiceinfo.getInvoiceRemark());
		model.addAttribute("vendorInvoiceNumber",invoiceinfo.getVendorInvoiceNumber());
		model.addAttribute("vendorInvoiceDate",invoiceinfo.getVendorInvoiceDate());
		EntityManager entityManagerObject=Database.getEntityManager();
			
		entityManagerObject.getTransaction().begin();
		entityManagerObject.persist(invoiceinfo);
		entityManagerObject.getTransaction().commit(); 
		entityManagerObject.close();
	}
	
	private static void insertToDbInvalid(Invalidinvoiceinfo invalidinvoiceinfo,ModelMap model){		
		model.addAttribute("invoiceNum",invalidinvoiceinfo.getInvoiceNum());
		model.addAttribute("invoiceDate",invalidinvoiceinfo.getInvoiceDate());
		model.addAttribute("invoiceType",invalidinvoiceinfo.getInvoiceType());
		model.addAttribute("invoiceAmount",invalidinvoiceinfo.getInvoiceAmount());
		model.addAttribute("prePaymentAmount",invalidinvoiceinfo.getPrePaymentAmount());
		model.addAttribute("paymentAmount",invalidinvoiceinfo.getPaymentAmount());
		model.addAttribute("description",invalidinvoiceinfo.getDescription());
		model.addAttribute("beneficiaryName",invalidinvoiceinfo.getBeneficiaryName());
		model.addAttribute("invoiceStatus",invalidinvoiceinfo.getInvoiceStatus());
		model.addAttribute("filename",invalidinvoiceinfo.getFilename());
		model.addAttribute("vendorId",invalidinvoiceinfo.getVendorId());
		model.addAttribute("vendorInvoiceNumber",invalidinvoiceinfo.getVendorInvoiceNumber());
		model.addAttribute("vendorInvoiceDate",invalidinvoiceinfo.getVendorInvoiceDate());  
		model.addAttribute("mailStatus",invalidinvoiceinfo.getMailStatus());  
		EntityManager entityManagerObject=Database.getEntityManager();
		
		entityManagerObject.getTransaction().begin();
		entityManagerObject.persist(invalidinvoiceinfo);
		entityManagerObject.getTransaction().commit();
		entityManagerObject.close();
	
	}
	
	private static void insertToVendorDb(Vendorinfo vendorinfo, ModelMap model) {
		model.addAttribute("vendorCode",vendorinfo.getVendorCode());
		model.addAttribute("vendorName",vendorinfo.getVendorName());
		model.addAttribute("purchaseOrder",vendorinfo.getPurchaseOrder());
		model.addAttribute("maximumPayment",vendorinfo.getMaximumPayment());
		model.addAttribute("minimumPayment",vendorinfo.getMinimumPayment());
		
		EntityManager entityManagerObject=Database.getEntityManager();	
		entityManagerObject.getTransaction().begin();
		entityManagerObject.persist(vendorinfo);
		entityManagerObject.getTransaction().commit(); 	
		entityManagerObject.close();
	}
	
	private static void insertToSummingDb(Aggregateinvoiceinfo aggregateinvoiceinfo, ModelMap model) {
		model.addAttribute("vendorCode",aggregateinvoiceinfo.getVendorCode());
		model.addAttribute("vendorName",aggregateinvoiceinfo.getVendorName());
		model.addAttribute("paymentAmount",aggregateinvoiceinfo.getPaymentAmount());
		model.addAttribute("invoiceStatus",aggregateinvoiceinfo.getInvoiceStatus());
		model.addAttribute("pane",aggregateinvoiceinfo.getPane());
		model.addAttribute("invoiceDate",aggregateinvoiceinfo.getInvoiceDate());
		model.addAttribute("pendingPayment",aggregateinvoiceinfo.getPendingPayment());
		model.addAttribute("remark",aggregateinvoiceinfo.getRemark());
		model.addAttribute("mailStatus",aggregateinvoiceinfo.getMailStatus());
		
		EntityManager entityManagerObject=Database.getEntityManager();	
		entityManagerObject.getTransaction().begin();
		entityManagerObject.persist(aggregateinvoiceinfo);
		entityManagerObject.getTransaction().commit(); 
		entityManagerObject.close();
	}
}