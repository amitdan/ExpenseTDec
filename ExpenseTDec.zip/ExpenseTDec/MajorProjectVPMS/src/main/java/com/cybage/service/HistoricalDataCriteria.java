package com.cybage.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.ModelAndView;

import com.cybage.configuration.LoggerClass;
import com.cybage.model.Aggregateinvoiceinfo;

// TODO: Auto-generated Javadoc
/**
 * The Class HistoricalDataCriteria.
 * 
 * @author palasht
 */
public class HistoricalDataCriteria {

	/** The Constant logger. */
	private static final LoggerClass loggerInstance = LoggerClass
			.getLoggerInstance();

	/**
	 * Apply criteria.
	 * 
	 * @param vendorCode
	 *            the vendor code
	 * @param paymentAmount
	 *            the payment amount
	 * @param invoiceNum
	 *            the invoice num
	 * @return the model and view
	 */
	@SuppressWarnings("unchecked")
	public ModelAndView applyCriteria(int vendorCode, int paymentAmount,
			String invoiceNum, String invoiceDate) {

		ArrayList<Aggregateinvoiceinfo> invoiceList;
		ArrayList<String> vendorInfo = new ArrayList<String>();
		EntityManager entityManagerObject = Database.getEntityManager();

		ModelAndView modelObject = new ModelAndView("paneProcessing");
		Map<String, String> historyMap = VendorHistory
				.getVendorHistory(vendorCode);
		ArrayList<String> historyList = new ArrayList<String>();
		ArrayList<String> historyListPeriod = new ArrayList<String>();
		for (Entry<String, String> entry : historyMap.entrySet()) {
			String[] splittingMonth = entry.getKey().split("/");
			historyListPeriod.add(getMonthName(splittingMonth[1]) + "-"
					+ splittingMonth[0]);
			historyList.add(entry.getValue());
		}
		modelObject.addObject("vendorHistoryPeriod", historyListPeriod);
		modelObject.addObject("vendorHistory", historyList);

		vendorInfo.add(String.valueOf(vendorCode));
		vendorInfo.add(String.valueOf(paymentAmount));
		vendorInfo.add(invoiceNum);
		vendorInfo.add(invoiceDate);

		invoiceList = (ArrayList<Aggregateinvoiceinfo>) entityManagerObject
				.createQuery(
						"select s from Aggregateinvoiceinfo s where s.vendorCode =:chrName")
				.setParameter("chrName", vendorCode).getResultList();

		if (invoiceList.size() != 0) {
			for (Iterator<Aggregateinvoiceinfo> iterator = invoiceList
					.iterator(); iterator.hasNext();) {
				Aggregateinvoiceinfo invoiceinfo = iterator.next();
				if (((invoiceinfo.getInvoiceStatus()).equals("Unprocessed"))
						|| (invoiceinfo.getPane())
								.equals("Satisfied Exception Criteria")
						|| (invoiceinfo.getInvoiceStatus()).equals("Heldback")
						|| (invoiceinfo.getInvoiceStatus()).equals("Processed")) {
					iterator.remove();
				}
			}
		}
		entityManagerObject.close();
		loggerInstance.logger.info("Number of items" + invoiceList.size());

		if (invoiceList.size() == 0) {
			modelObject.addObject("vendorInfo", vendorInfo);
			modelObject.addObject("paneNumber", "pane3");
			modelObject.addObject("minimum", "");
			modelObject.addObject("maximum", "");
			return modelObject;
		} else {
			int averagePaymentAmount = 0;
			EntityManager entityManagerObject1 = Database.getEntityManager();
			StoredProcedureQuery storedProcedure = entityManagerObject1
					.createStoredProcedureQuery("computeAverage");
			storedProcedure.registerStoredProcedureParameter("venID",
					Integer.class, ParameterMode.IN);
			storedProcedure.registerStoredProcedureParameter("average",
					Integer.class, ParameterMode.OUT);
			storedProcedure.setParameter("venID", vendorCode);
			storedProcedure.execute();
			averagePaymentAmount = (Integer) storedProcedure
					.getOutputParameterValue("average");
			entityManagerObject1.close();
			loggerInstance.logger.info("averagePaymentAmount: "
					+ averagePaymentAmount);

			if (paymentAmount <= averagePaymentAmount) {
				// return Pane1 Page

				loggerInstance.logger.info("paymentAmount: " + paymentAmount);

				modelObject.addObject("vendorInfo", vendorInfo);
				modelObject.addObject("paneNumber", "pane1");
				return modelObject;

			} else {
				// return Pane2 Page
				loggerInstance.logger.info("Returning Pane 2 Page");
				modelObject.addObject("vendorInfo", vendorInfo);
				modelObject.addObject("paneNumber", "pane2");
				modelObject.addObject("averagePaymentAmount", averagePaymentAmount);
				return modelObject;

			}

		}

	}

	private static String getMonthName(String splittingMonth) {
		String monthString;
		int month = Integer.parseInt(splittingMonth);
		switch (month) {
		case 0:
			monthString = "0";
			break;
		case 1:
			monthString = "Jan";
			break;
		case 2:
			monthString = "Feb";
			break;
		case 3:
			monthString = "Mar";
			break;
		case 4:
			monthString = "Apr";
			break;
		case 5:
			monthString = "May";
			break;
		case 6:
			monthString = "June";
			break;
		case 7:
			monthString = "July";
			break;
		case 8:
			monthString = "Aug";
			break;
		case 9:
			monthString = "Sep";
			break;
		case 10:
			monthString = "Oct";
			break;
		case 11:
			monthString = "Nov";
			break;
		case 12:
			monthString = "Dec";
			break;
		default:
			monthString = "Invalid month";
			break;
		}
		return monthString;
	}

}