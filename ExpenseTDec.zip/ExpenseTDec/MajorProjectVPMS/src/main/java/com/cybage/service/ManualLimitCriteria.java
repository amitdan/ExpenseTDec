package com.cybage.service;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cybage.configuration.LoggerClass;

// TODO: Auto-generated Javadoc
/**
 * The Class ManualLimitCriteria.
 * @author palasht
 */
public class ManualLimitCriteria {
	
	/** The Constant logger. */
	private static final LoggerClass loggerInstance = LoggerClass.getLoggerInstance();
	
	/**
	 * Apply criteria.
	 *
	 * @param maxLimit the max limit
	 * @param vendorCode the vendor code
	 * @param paymentAmount the payment amount
	 * @return true, if successful
	 */
	public boolean applyCriteria(int minLimit,int maxLimit,int vendorCode,int paymentAmount){
		loggerInstance.logger.info("Inside Manual Limitor");
		loggerInstance.logger.info("Minimum Limit"+minLimit);	
		loggerInstance.logger.info("Maximum Limit"+maxLimit);
		loggerInstance.logger.info("vendorCode"+vendorCode);
		
		EntityManager entityManagerObject = Database.getEntityManager();
				EntityTransaction updateTransaction = entityManagerObject.getTransaction();
				updateTransaction.begin();
				
				Query query = entityManagerObject.createQuery("UPDATE Vendorinfo vendorinfo SET vendorinfo.minimumPayment = ?1 "
						+ "WHERE vendorinfo.vendorCode= :parameter");
						query.setParameter(1, minLimit);
						query.setParameter("parameter", vendorCode);
						
				Query query2 = entityManagerObject.createQuery("UPDATE Vendorinfo vendorinfo SET vendorinfo.maximumPayment = ?1 "
						+ "WHERE vendorinfo.vendorCode= :parameter");
						query2.setParameter(1, maxLimit);
						query2.setParameter("parameter", vendorCode);
								
						int updateCount1 = query.executeUpdate();
						int updateCount2 = query2.executeUpdate();
						loggerInstance.logger.info(updateCount1+"\n"+updateCount2);
						
				updateTransaction.commit();
				
				entityManagerObject.close();
				
		
		if(paymentAmount<=maxLimit){
			
			return true;
		}
		else{
			return false;
		}
		
	}
}