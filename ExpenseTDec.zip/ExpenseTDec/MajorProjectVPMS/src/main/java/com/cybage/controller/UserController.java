package com.cybage.controller;

import java.util.ArrayList;

import javax.servlet.http.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import com.cybage.configuration.LoggerClass;
import com.cybage.dao.UserDAO;
import com.cybage.model.*;

/**
 * Handles requests for the application user task.
 */
@Controller
public class UserController {
	private static LoggerClass loggerInstance = LoggerClass.getLoggerInstance();
	String fileToUpdate;	
	
	@RequestMapping(value = "/userHome", method = RequestMethod.GET)
	public ModelAndView userMain() {	  	 	
		loggerInstance.logger.info("Redirected to User Page");
		ModelAndView modelObject = new ModelAndView("userHome");
		modelObject.addObject("value", "user");
		return modelObject;
		
	}
	
	@RequestMapping(value = "/superAdmin", method = RequestMethod.GET)
	public ModelAndView superadmin() {	  	 	
		loggerInstance.logger.info("Redirected to User Page");
		return new ModelAndView("superAdminHome");		
	}
	
	@Autowired
    private UserDAO userDao;
	
	@RequestMapping(value="/uploadExcelFile" , method = RequestMethod.POST)
	public ModelAndView uploadExcelFile( HttpServletRequest request,HttpServletResponse response,ModelMap model){
		String checkFile=userDao.uploadExcelFile(request,response,model);
		loggerInstance.logger.info(checkFile);			
			ModelAndView modelObject = new ModelAndView("userHome");
			modelObject.addObject("message", checkFile);			
			return modelObject;
						
	} 
	
	@RequestMapping(value="/viewExcelFilesbyUser" , method = RequestMethod.GET)
	public ModelAndView viewExcelFilesbyUser( ModelMap model){
		ArrayList<Fileinfo> fileList =userDao.viewExcel();		 
		return new ModelAndView("viewExcelFilesbyUser","file",fileList);
				
	}
	
	@RequestMapping(value="/updateFileByUser" , method = RequestMethod.GET)
	public ModelAndView updateFileByUser(@RequestParam("filename") String filename){
		fileToUpdate=filename;			
		ModelAndView modelObject = new ModelAndView("updateFile");
		modelObject.addObject("message", "Do verify as your original file will be deleted");
		return modelObject;						
	}
	
	@RequestMapping(value="/updateExcelFile" , method = RequestMethod.POST)
	public ModelAndView updateExcelFile( HttpServletRequest request,HttpServletResponse response,ModelMap model){
		loggerInstance.logger.info("file to update"+fileToUpdate);
		String checkFile=userDao.updateExcelFile(request,response,model,fileToUpdate);
		loggerInstance.logger.info(checkFile);
			ArrayList<Fileinfo> fileList =userDao.viewExcel();
			ModelAndView modelObject = new ModelAndView("viewExcelFilesbyUser");
			modelObject.addObject("message", checkFile);
			modelObject.addObject("file",fileList);
			
			return modelObject;
							
	} 
	
	@RequestMapping(value="/download" , method = RequestMethod.GET)
	public ModelAndView viewprocessFile(@RequestParam("filename") String filename, ModelMap model, HttpServletResponse response){
		
		loggerInstance.logger.info("Starting file download");
		boolean downloadFile=userDao.downloadFileByuser(filename,response);
		
		if(downloadFile)
			return new ModelAndView("userHome");
		else
			return new ModelAndView("viewExcelFilesbyUser");				
	}
	
	@RequestMapping(value="/heldbackQueriescall" , method = RequestMethod.GET)
	public ModelAndView viewHeldbackQueries(@ModelAttribute("login") Login login, ModelMap model){
		
		ArrayList<Aggregateinvoiceinfo> heldBackList =userDao.heldbackQueries();
		return new ModelAndView("viewHeldbackQueries","invoice",heldBackList);				
	}
}
