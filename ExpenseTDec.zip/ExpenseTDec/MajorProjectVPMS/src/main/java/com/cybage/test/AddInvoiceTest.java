package com.cybage.test;

import static org.junit.Assert.*;

import org.junit.Test;
import org.springframework.ui.ModelMap;

import com.cybage.service.AddInvoiceToDB;

public class AddInvoiceTest {

	AddInvoiceToDB addInvoiceToDB=new AddInvoiceToDB();
	@Test
	public void testAddInvoiceToDB() {
		
		String filename="NEFT_2017-09-08_11.28.54.012";
		ModelMap model=new ModelMap();
		String createdBy="palasht";

		//boolean result=addInvoiceToDB.addExcelToDB(filename,createdBy, model);
	
		//assertEquals(true, result);
	
	}
	
	@Test
	public void testUpdate()
	{
		String iD="NEFT_2017-09-08_11.28.54.012";
		ModelMap model=new ModelMap();
		//boolean result=addInvoiceToDB.updateFileinfo(iD, model);
		
		//assertEquals(true,result);
	}

}