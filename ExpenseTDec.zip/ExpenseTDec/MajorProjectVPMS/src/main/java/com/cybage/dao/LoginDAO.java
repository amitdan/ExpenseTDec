package com.cybage.dao;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

@Service
public interface LoginDAO {

	boolean validate(String username, String password,
			HttpServletRequest request);

	String checkRole(String username);

}
