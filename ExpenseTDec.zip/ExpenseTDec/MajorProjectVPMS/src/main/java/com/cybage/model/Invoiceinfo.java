package com.cybage.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the invoiceinfo database table.
 * 
 */
@Entity
@NamedQuery(name="Invoiceinfo.findAll", query="SELECT i FROM Invoiceinfo i")
public class Invoiceinfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int id;

	private String beneficiaryName;

	private String description;

	private String fileName;

	private int invoiceAmount;

	@Temporal(TemporalType.DATE)
	private Date invoiceDate;

	private String invoiceNum;

	private String invoiceRemark;

	private String invoiceStatus;

	private String invoiceType;

	private int paymentAmount;

	private int prePaymentAmount;

	private int vendorCode;

	@Temporal(TemporalType.DATE)
	private Date vendorInvoiceDate;

	private String vendorInvoiceNumber;

	public Invoiceinfo() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBeneficiaryName() {
		return this.beneficiaryName;
	}

	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getFileName() {
		return this.fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public int getInvoiceAmount() {
		return this.invoiceAmount;
	}

	public void setInvoiceAmount(int invoiceAmount) {
		this.invoiceAmount = invoiceAmount;
	}

	public Date getInvoiceDate() {
		return this.invoiceDate;
	}

	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getInvoiceNum() {
		return this.invoiceNum;
	}

	public void setInvoiceNum(String invoiceNum) {
		this.invoiceNum = invoiceNum;
	}

	public String getInvoiceRemark() {
		return this.invoiceRemark;
	}

	public void setInvoiceRemark(String invoiceRemark) {
		this.invoiceRemark = invoiceRemark;
	}

	public String getInvoiceStatus() {
		return this.invoiceStatus;
	}

	public void setInvoiceStatus(String invoiceStatus) {
		this.invoiceStatus = invoiceStatus;
	}

	public String getInvoiceType() {
		return this.invoiceType;
	}

	public void setInvoiceType(String invoiceType) {
		this.invoiceType = invoiceType;
	}

	public int getPaymentAmount() {
		return this.paymentAmount;
	}

	public void setPaymentAmount(int paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public int getPrePaymentAmount() {
		return this.prePaymentAmount;
	}

	public void setPrePaymentAmount(int prePaymentAmount) {
		this.prePaymentAmount = prePaymentAmount;
	}

	public int getVendorCode() {
		return this.vendorCode;
	}

	public void setVendorCode(int vendorCode) {
		this.vendorCode = vendorCode;
	}

	public Date getVendorInvoiceDate() {
		return this.vendorInvoiceDate;
	}

	public void setVendorInvoiceDate(Date vendorInvoiceDate) {
		this.vendorInvoiceDate = vendorInvoiceDate;
	}

	public String getVendorInvoiceNumber() {
		return this.vendorInvoiceNumber;
	}

	public void setVendorInvoiceNumber(String vendorInvoiceNumber) {
		this.vendorInvoiceNumber = vendorInvoiceNumber;
	}

}