package com.cybage.service;


import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cybage.model.Userrole;
import com.cybage.configuration.*;

public class Database {

	/** The property. */
	static PropertyClass property;
	
	/** The logger instance. */
	static LoggerClass loggerInstance;
	
	static Map<String,String> jpaProperties = new HashMap<String, String>();
	static{
		property = new PropertyClass();
		loggerInstance = LoggerClass.getLoggerInstance();
		try {
			jpaProperties.put(property.getHibernateConnection(),
					property.getDatabaseConnectionURL());
			jpaProperties.put(property.getHibernateDriverClass(),
					property.getDatabaseDriver());
			jpaProperties.put(property.getHibernateUsername(),
					property.getDatabaseUsername());
			jpaProperties.put(property.getHibernatePassword(),
					property.getDatabasePassword());
			jpaProperties.put(property.getHibernateAutodetect(),
					property.getDatabaseAutodetect());
			jpaProperties.put(property.getHibernateShowSql(),
					property.getDatabaseShowSql());
			jpaProperties.put(property.getHibernateFormatSql(),
					property.getDatabaseFormatSql());
			jpaProperties.put("hbm2ddl.auto", "update");
			jpaProperties.put("connection.release_mode", "auto");
		} catch (IOException e) {
			loggerInstance.logger.error(e);
			ExceptionHandling.invalidDatabaseConfiguration();
		}
	}
	
	private static EntityManagerFactory emFactory = Persistence.createEntityManagerFactory("MajorProjectVPMS",jpaProperties);
	public static EntityManager getEntityManager() {
		EntityManager entityManager=emFactory.createEntityManager();
		entityManager.getEntityManagerFactory().getCache().evictAll();
		return entityManager;
	}
	
	@SuppressWarnings("unchecked")
	public static List<Userrole> getAlluser(){
		EntityManager entityManager = getEntityManager();
		return entityManager.createQuery("select s from Userrole s").getResultList();
	}
}
