package com.cybage.dao;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;
import org.springframework.web.servlet.ModelAndView;

import com.cybage.model.Aggregateinvoiceinfo;
import com.cybage.model.Fileinfo;

// TODO: Auto-generated Javadoc
/**
 * The Interface AdminDAO.
 * 
 * @author palasht
 */
@Service
public interface AdminDAO {

	/**
	 * View excel files.
	 * 
	 * @return the array list
	 */
	ArrayList<Fileinfo> viewExcelFiles();

	/**
	 * Process file.
	 * 
	 * @param iD
	 *            the i D
	 * @param createdBy
	 *            the created by
	 * @param model
	 *            the model
	 * @return the string
	 */
	String processFile(String iD, String createdBy, ModelMap model);

	/**
	 * Gets the payment details.
	 * 
	 * @return the payment details
	 */
	ModelAndView getPaymentDetails();

	/**
	 * Gets the variance.
	 * 
	 * @param variance
	 *            the variance
	 * @param vendorID
	 *            the vendor ID
	 * @param payment
	 *            the payment
	 * @param invoiceNum
	 *            the invoice num
	 * @return the variance
	 */
	ModelAndView getVariance(String variance, int vendorID, int payment,
			String invoiceNum, String invoiceDate);

	/**
	 * Manual limit.
	 * 
	 * @param maximumLimit
	 *            the maximum limit
	 * @param vendorID
	 *            the vendor ID
	 * @param invoiceNum
	 *            the invoice num
	 * @param payment
	 *            the payment
	 * @return the model and view
	 */
	ModelAndView manualLimit(int minimumLimit, int maximumLimit, int vendorID,
			String invoiceNum, int payment, String invoiceDate);

	/**
	 * Update status.
	 * 
	 * @param invoiceNum
	 *            the invoice num
	 * @return the array list
	 */
	ArrayList<Aggregateinvoiceinfo> updateStatus(String invoiceNum);

	/**
	 * Update excel file.
	 * 
	 * @param request
	 *            the request
	 * @param response
	 *            the response
	 * @param model
	 *            the model
	 * @param fileToUpdate
	 *            the file to update
	 * @return the string
	 */
	String updateExcelFile(HttpServletRequest request,
			HttpServletResponse response, ModelMap model, String fileToUpdate);

	boolean downloadFileByAdmin(String filename, HttpServletResponse response);

}